# Dapeng Zhao (Eagle)
# dapengz@andrew.cmu.edu or tim.eagle.zhao@gmail.com
# 11 Sep 2019

def main():
    print "No code for Q4."

if __name__ == "__main__":
    main()
